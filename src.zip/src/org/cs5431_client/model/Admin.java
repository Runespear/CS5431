package org.cs5431_client.model;

public class Admin extends Account {
    //TODO: populate
}
