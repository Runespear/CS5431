package org.cs5431_client.model;

public enum AccountActionType {
    CREATE, CHANGE_PWD, DELETE
}
