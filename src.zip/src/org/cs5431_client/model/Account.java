package org.cs5431_client.model;

public class Account {
    int id;
    String username;
    String password; //TODO: lol not string

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

}
