package org.cs5431_client.model;

public class AccountLogEntry {

    public int userId;
    public int timestamp;
    public AccountActionType action;

}
