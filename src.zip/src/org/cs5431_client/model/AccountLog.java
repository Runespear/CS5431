package org.cs5431_client.model;

import java.util.List;

public class AccountLog {
    private List<AccountLogEntry> logEntries;

    //TODO: anything else?
}
