package org.cs5431_client.model;

//File System Object (FSO) type
public enum FSOType {
    FILE, FOLDER
}
