package org.cs5431_client.model;

public enum PrivType {
    VIEW, EDIT
}
