package org.cs5431_client.model;

public enum FileActionType {
    DOWNLOAD, CREATE_FOLDER, DELETE, OVERWRITE, RENAME, UPLOAD_FILE, ADD_PRIV, REMOVE_PRIV, ROLLBACK
}
